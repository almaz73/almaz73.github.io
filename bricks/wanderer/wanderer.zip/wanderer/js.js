function transit() {
    document.getElementById('content').style.opacity = 1;
}